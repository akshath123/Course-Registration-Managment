
package crm;

import javax.swing.ImageIcon ;
import java.awt.BorderLayout ;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JFrame ;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton ;
import javax.swing.JLabel ;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.sql.*;


public class Login extends JFrame implements ActionListener{
    
    JLabel login_l, password_l, title;
    JButton login;
    JTextField login_t ;
    JPasswordField password_t ;
    
    Login()
    {
       changePath() ;   
    }
    
    public void changePath() 
    {
        Login ob = new Login(1);
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setLocationRelativeTo(null);
        ob.setVisible(true) ;
    }
    
    private Login(int i)
    {
        super("Login") ;
        setSize(800, 600) ;
        
        setLayout(new BorderLayout()) ;
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/Images/background2.png"))) ;
        add(background);
        
        background.setLayout(null);
        
        login_l = new JLabel("Login") ;
        login_l.setFont(new Font("Serif",Font.ITALIC,30)) ; 
        login_l.setBounds(205, 165, 120, 50) ;
        login_l.setForeground(Color.BLACK);
        
        background.add(login_l) ;
        
        password_l = new JLabel("Password") ;
        password_l.setFont(new Font("Serif", Font.ITALIC, 30)) ;
        password_l.setBounds(160, 265, 220, 50) ;
        password_l.setForeground(Color.BLACK);
        
        background.add(password_l) ;
        
        login_t = new JTextField("") ;
        login_t.setOpaque(false) ;
        login_t.setFont(new Font("Serif",Font.BOLD,20));
        login_t.setForeground(Color.BLACK) ;
        login_t.setCaretColor(Color.WHITE) ;
        login_t.setHorizontalAlignment(JTextField.CENTER) ;
        login_t.setBounds(330, 180, 220, 30);
        
        background.add(login_t) ;
        
        password_t = new JPasswordField("") ;
        password_t.setOpaque(false);
        password_t.setFont(new Font("Serif",Font.BOLD,20)) ;
        password_t.setCaretColor(Color.WHITE) ;
        password_t.setForeground(Color.BLACK) ;
        password_t.setHorizontalAlignment(JTextField.CENTER);
        password_t.setBounds(330, 280, 220, 30) ;
        
        background.add(password_t) ;
        
        login = new JButton("Login") ;
        login.setForeground(Color.BLACK) ;
        login.setFont(new Font("Serif", Font.BOLD, 20)) ;
        login.setBounds(350, 370, 130, 40) ;
        login.setFocusPainted(false) ;
       
        background.add(login) ;
        
        title = new JLabel("Course Registration ") ;
        title.setFont(new Font("Serif",Font.BOLD|Font.ITALIC, 55)) ;
        title.setBounds(155, 30, 600, 80) ;
        title.setForeground(Color.BLACK) ;
        
        background.add(title);
        
        login.addActionListener(this) ;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        String regno  ;
        int flag = 1 ;
        regno = login_t.getText().toUpperCase() ;
        char[] pass = password_t.getPassword() ;
        String password = String.valueOf(pass) ;
        
        String sql_statement = "select student.password , department.dno from student ,department where student.dno = department.dno and student.regno = '" +regno+"'"  ;
        
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
            Statement stm = con.createStatement() ;
            ResultSet res = stm.executeQuery(sql_statement) ;
            
            while( res.next() )
            {
                String db_password = res.getString("password") ;
                int depart = res.getInt("dno") ;
                System.out.println(password);
                if( db_password.equals(password) )
                {
                    new Selection(depart, regno) ; 
                    dispose() ;
                }
                else
                {
                      flag = 0 ;
                }
            }
            
            if( flag == 0 )
            {
                JOptionPane.showMessageDialog(null, "Account doesn't exist" );
                login_t.setText("") ;
                password_t.setText("") ;
            }
            
            if( regno.equals("") || password.equals("") )
            {
                JOptionPane.showMessageDialog(null, "Invalid Entry") ;
                login_t.setText("") ;
                password_t.setText("") ;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
