package crm;

import java.awt.BorderLayout ;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon ;
import javax.swing.JFrame ;
import javax.swing.JButton ;
import javax.swing.JLabel ;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class RegisteredCourseView extends JFrame implements ActionListener{
    
    JButton b[] = new JButton[42];
    JLabel background , title ;
    char lunch[] = {'L','U','N','C','H'} ;
    String weekdays[] = {"Mon", "Tue", "Wed", "Thu", "Fri"} ;
    int index_w = 0 ;
    int index_l = 0 ;
    int time1 = 8 ;
    int time2 = 0 ;
    JButton goback, details ;
    
    RegisteredCourseView(String regno)
    {
        changePath(regno);
    }
    
    public void changePath(String regno)
    {
        RegisteredCourseView ob = new RegisteredCourseView(1,regno) ;
        ob.setVisible(true) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setLocationRelativeTo(null) ;
    }
    
    RegisteredCourseView(int i, String regno)
    {
        super(" Registered Course View ") ;
        
        setSize(1300, 650) ;
        
        for( i = 0 ; i < 42 ; i++ )
        b[i] = new JButton("") ;
        
        background = new JLabel(new ImageIcon(getClass().getResource("/Images/background2.png"))) ;
        setLayout(new BorderLayout()) ;
        add(background) ;
        
        background.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 10));
        
        title = new JLabel("Time Table") ;
        title.setBounds(600, 50, 120, 20) ;
        title.setFont(new Font("Serif", Font.ITALIC|Font.BOLD, 20));
        
        background.add(title) ;
        
        JPanel p1 = new JPanel() ;
        p1.setOpaque(false) ;
        
        p1.setLayout(new GridLayout(6,7,0,0)) ;
        
        for( i = 0 ; i < 42 ; i++ )
        {
            b[i] = new JButton("");
            b[i].setContentAreaFilled(false);
            b[i].addActionListener(this) ;
            Color mycolor = new Color(255,255,204) ;
            b[i].setBackground(mycolor) ;
            b[i].setFocusPainted(false) ;
            b[i].setOpaque(true) ;
            b[i].setPreferredSize(new Dimension(170, 75)) ;
            
            // Writing the Weekdays
            
            if( i == 7 || i == 14 || i == 21 || i == 28 || i == 35  )
            {
                b[i].setText(weekdays[index_w++]);
                b[i].setFont(new Font("Serif",Font.ITALIC,20)) ;
                Color mcolor = new Color(225,225,204) ;
                b[i].setBackground(mcolor) ;
                b[i].setOpaque(true) ;
            }
            
            // Writing the Lunch 
            
            if( i == 11 || i == 18 || i == 25 || i == 32 || i == 39 )
            {
                b[i].setFont(new Font("Serif",Font.ITALIC,25)) ;
                b[i].setText("" +lunch[index_l++]) ;
                Color mcolor = new Color(225,225,204) ;
                b[i].setBackground(mcolor) ;
                b[i].setBorder(null) ;
            }
            
            if( i == 0 )
            {
                b[i].setText("Timing") ;
                b[i].setFont(new Font("Serif",Font.ITALIC,25)) ;
                Color mcolor = new Color(225,225,204) ;
                b[i].setBackground(mcolor) ;
            }
            
            // Setting the timing of each peroid 
            
            if( i > 0 && i < 7 )
            {
                time2 = time1 ;
                time2++ ;
                
                if( time1 < 12 && time2 < 12 )
                b[i].setText(""+time1 +":00AM - " +time2 +":00AM" ) ;
                else if( time1 < 12 && time2 >= 12 )
                b[i].setText(""+time1 +":00AM - " +time2 +":00PM" ) ;    
                else if( time1 == 12 && time2 > 12 )
                b[i].setText(""+time1 +":00PM - " +(time2-12) +":00PM" ) ;        
                else if( time1 > 12 && time2 > 12 )
                b[i].setText(""+(time1-12) +":00PM - " +(time2-12) +":00PM" ) ;       
                b[i].setFont(new Font("Serif",Font.ITALIC,15)) ;
                Color mcolor = new Color(65,105,255) ;
                b[i].setBackground(mcolor) ;
                time1++ ;
                time2++ ;
            }            
            
            // ----------------------- Fixing the Morning and evening slots ----------------------------- //
        
            b[8].setActionCommand("A1");
            b[9].setActionCommand("C1");
            b[10].setActionCommand("B1");
            b[12].setActionCommand("A2");
            b[13].setActionCommand("C2");
            b[15].setActionCommand("D1");
            b[16].setActionCommand("E1");
            b[17].setActionCommand("A1");
            b[19].setActionCommand("D2");
            b[20].setActionCommand("E2");
            b[22].setActionCommand("B1");
            b[23].setActionCommand("C1");
            b[24].setActionCommand("E1");
            b[26].setActionCommand("B2");
            b[27].setActionCommand("C2");
            b[29].setActionCommand("E1");
            b[30].setActionCommand("D1");
            b[31].setActionCommand("A1");
            b[33].setActionCommand("A2");
            b[34].setActionCommand("D2");
            b[36].setActionCommand("C1");
            b[37].setActionCommand("B1");
            b[38].setActionCommand("D1");
            b[40].setActionCommand("E2");
            b[41].setActionCommand("B2");
            p1.add(b[i]) ;
        }
        background.add(p1) ;
        
        /* ------------------------------ Setting the Course Code ---------------------------------- */
        
        String sql_cmd = "SELECT ccode,slot FROM registered WHERE regno ='" +regno +"'" ;
        System.out.println(regno) ;
        try{
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
        Statement stm = con.createStatement() ;      
        ResultSet res = stm.executeQuery(sql_cmd) ;
        
          while( res.next() )
        {
            String subcode = res.getString("ccode") ;
            String slot = res.getString("slot") ;
            
            for( i = 8 ; i < 42 ; i++ )  // Performing a linear search to find slot number 
            {
                if( i != 7 || i != 14 || i != 21 || i != 28 || i != 35 ||  i != 11 || i != 18 || i != 25 || i != 32 || i != 39 )
                {
                    String temp_slot = b[i].getActionCommand() ;
                    if( temp_slot.equals(slot) )
                    {
                        b[i].setText(subcode) ;
                        b[i].setOpaque(true);
                        b[i].setFont(new Font("Serif",Font.ITALIC|Font.BOLD, 15));
                        Color mycolor = new Color(127,255,0) ;
                        b[i].setBackground(mycolor);
                    }
                }
            }
        }
     }
     catch(SQLException s)
     {
          s.printStackTrace() ;
     }
        
        JPanel p = new JPanel() ;
        p.setOpaque(false) ;
        p.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20)) ;

        // -------------------------- Going back to selection class ---------------------------------//
        
        goback = new JButton("Go Back") ;
        goback.setPreferredSize(new Dimension(120, 30)) ;
        p.add(goback) ;
        
        goback.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae)
                {
                    int d_no = 0 ;
                    try{
                        String sql_cmd = "SELECT dno FROM student WHERE regno='" +regno +"'" ;
                        
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
                        Statement stm = con.createStatement() ;      
                        ResultSet res = stm.executeQuery(sql_cmd) ;
                        
                        while( res.next() )
                        {
                            d_no = res.getInt("dno") ;
                        }
                    }
                    catch(SQLException e)
                    {
                        e.printStackTrace() ;
                    }
                    new Selection(d_no,regno) ;
                    dispose();
                }
        });
        
        // ---------------------------------- Seeing the details of the subject ----------------------------------- //
        
        details = new JButton("View Details") ;
        details.setPreferredSize(new Dimension(120, 30));
        details.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                new Registration(regno) ;
                dispose() ;
            }
        }) ;
        
        p.add(details) ;
        
        background.add(p) ;
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        String selected = e.getActionCommand().toString() ;
        
        System.out.printf(selected) ;
    }
}
