
package crm;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JFrame ;
import javax.swing.JLabel ;
import javax.swing.JButton ;

public class Registration extends JFrame{
    
    JButton Back ;
    JLabel faculty, credits, subcode, title ;
    JLabel faculty_l, credits_l, subcode_l, title_l;
    JLabel background ;
    JLabel border ;
    JLabel ctaken;
    
    int y ;
    int total_credits = 0 ;
    
    Registration(String regno) 
    {
        changePath(regno) ;
    }
    
    public void changePath(String regno) 
    {
       Registration ob = new Registration(1,regno) ;
       ob.setLocationRelativeTo(null) ;
       ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
       ob.setVisible(true) ;
    }
    
    Registration(int i, String regno)
    {
        super("Faculty List") ;
        
        setSize(900, 400) ;
        
        setLayout(new BorderLayout()) ;
        background = new JLabel(new ImageIcon(getClass().getResource("/Images/background2.png"))) ;
        
        add(background) ;
        
        faculty = new JLabel("Course Title") ;
        faculty.setFont(new Font("Serif",Font.ITALIC,20)) ;
        faculty.setBounds(50, 20, 150, 50) ;
        background.add(faculty) ;
           
        credits = new JLabel("Credits") ;
        credits.setFont(new Font("Serif",Font.ITALIC,20)) ;
        credits.setBounds(300, 20, 100, 50) ;
        background.add(credits) ;
        
        subcode = new JLabel("Course Code") ;
        subcode.setFont(new Font("Serif",Font.ITALIC,20)) ;
        subcode.setBounds(500, 20, 150, 50);
        background.add(subcode) ;
        
        faculty = new JLabel("Faculty Name") ;
        faculty.setFont(new Font("Serif",Font.ITALIC,20)) ;
        faculty.setBounds(720, 20, 150, 50) ;
        background.add(faculty) ;
                
        border = new JLabel("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------") ;          
        border.setBounds(45,60,800,20) ;
        background.add(border) ;
        
        y = 80 ; // y coordinate for changing the label position dynamicaly 
        
        /*---------------------------------- Database Code ------------------------------------------ */
        
        String sql_cmd = "SELECT ccode, fid, slot FROM registered WHERE regno ='" +regno +"'" ;
        
        try{
         String ccode = "" ;
         int fid = 0 ;
         int credits = 0 ;
         String slot = "" ;
         String fname = "" ;
         String title = "" ;
            
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
        Statement stm = con.createStatement() ;
        ResultSet rs = stm.executeQuery(sql_cmd) ;
        
        while( rs.next() )
        {
            ccode = rs.getString("ccode") ;
            fid = rs.getInt("fid") ;
            slot = rs.getString("slot") ;
                     
            String sql_cmd1 = "SELECT cname, credits FROM course WHERE ccode ='" +ccode +"'" ;
            try{
            
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
            Statement stm1 = con1.createStatement() ;
            ResultSet r = stm1.executeQuery(sql_cmd1) ;
             
             while( r.next() ) 
             {
                 title = r.getString("cname") ;
                 credits = r.getInt("credits") ;
                 total_credits += credits ;
             }
            }catch(SQLException e)
            {
                e.printStackTrace() ;
            }
             
             String sql_cmd2 = "SELECT name FROM faculty WHERE fid =" +fid ;
            
            Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
            Statement stm2 = con2.createStatement() ;
            ResultSet r2 = stm2.executeQuery(sql_cmd1) ;
            
             r2 = stm2.executeQuery(sql_cmd2) ;
             
             while( r2.next() )
             {
                 fname = r2.getString("name") ;
             }
             
            title_l = new JLabel(title) ;
            title_l.setFont(new Font("Serif",Font.ITALIC,20)) ;
            title_l.setBounds(52, y, 200, 50) ;
            
            credits_l = new JLabel(""+credits) ;
            credits_l.setFont(new Font("Serif",Font.ITALIC,20)) ;
            credits_l.setBounds(325, y, 50, 50);
            
            subcode_l = new JLabel(ccode) ;
            subcode_l.setFont(new Font("Serif",Font.ITALIC,20)) ;
            subcode_l.setBounds(508, y, 100, 50) ;
           
            faculty_l = new JLabel(fname) ;
            faculty_l.setFont(new Font("Serif",Font.ITALIC,20)) ;
            faculty_l.setBounds(729, y, 100, 50) ;
                              
            background.add(title_l) ;
            background.add(credits_l) ;
            background.add(subcode_l) ;
            background.add(faculty_l) ;
            
            y += 50 ; // Incrementing y for the next Row */
        }
        }catch(SQLException e) 
        {
            e.printStackTrace();
        }
        
            ctaken = new JLabel("Credits Taken:" +total_credits) ;
            ctaken.setFont(new Font("Serif",Font.ITALIC,20)) ;
            ctaken.setBounds(200, 300, 150, 20) ;
            background.add(ctaken) ;
            
            Back = new JButton("Back") ;
            Back.setBounds(550, 300, 100, 25) ;
            Back.setFocusPainted(false) ;
            Back.addActionListener(new ActionListener(){
                
                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    new RegisteredCourseView(regno) ;
                    dispose() ;
                }
            });
            background.add(Back);
            
    }
    
}
