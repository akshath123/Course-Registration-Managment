
package crm;

public class CRM {

    public static void main(String[] args) {
  
        new Login() ;  
    }    
}
