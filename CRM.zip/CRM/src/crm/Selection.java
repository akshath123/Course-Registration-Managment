package crm;

import java.awt.Font ;
import javax.swing.JButton ;
import javax.swing.JRadioButton ;
import javax.swing.ImageIcon ;
import javax.swing.JTextField ;
import java.awt.BorderLayout ;
import java.awt.Color;
import javax.swing.JLabel ;
import java.awt.event.ActionEvent ;
import java.awt.event.ItemEvent ;
import java.awt.event.ItemListener ;
import javax.swing.JComboBox ;
import java.awt.event.ActionListener ;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame ;
import javax.swing.ButtonGroup ;
import javax.swing.JOptionPane;

public class Selection extends JFrame implements ItemListener{
    
    JComboBox course_list ;
    JLabel title1 ;
    JLabel cname , fname, slot ;
    JLabel fname1, fname2, fname3 ;
    JLabel slot1, slot2, slot3 ;
    JButton register ;
    JRadioButton f1, f2, f3 ;
    JLabel background ;
    ButtonGroup bg  ;
    JTextField seat1, seat2, seat3 ;
    JButton logout ;
    JButton Timetable ;
    
    int flag1 = 1 ,flag2 = 1 ,flag3 = 1 ;
    int flag = 0 ;
    int faculty_id[] = new int[3] ;
    int fid_index = 0 ;
    int dno ;
    String sql_command ;
    String register_no ;
    String sub_code , course_code = "";
    
    Selection(int i, String regno) 
    {
        changePath(i,regno) ;
    }
    
    public void changePath(int dept, String regno) 
    {
        Selection ob = new Selection(1,dept, regno);
        ob.setLocationRelativeTo(null) ;
        ob.setVisible(true) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
    }
    
    Selection(int i, int dept,String regno)
    {
        super("Select Your Course") ;
     
        System.out.println("R:" +regno) ;
    
        register_no = regno ;
        
        setSize(800, 600) ;
        System.out.println("Selection department " +dept) ;
        setLayout(new BorderLayout()) ;
        background = new JLabel(new ImageIcon(getClass().getResource("/Images/background2.png"))) ;
        add(background);
        
        title1 = new JLabel("Select According to Course Code") ;
        title1.setFont(new Font("Serif", Font.ITALIC, 20)) ;
        title1.setBounds(60, 60, 300, 50) ;
        title1.setForeground(Color.BLACK) ;
        
        background.add(title1) ;
        
         dno = dept ;
         
        course_list = new JComboBox() ;
        course_list.addItem("") ;
        course_list.setBounds(60, 120, 100, 20);
        course_list.addItemListener(this) ;
        
        // --------------------------------- Database code ----------------------------------------
        
        sql_command  = "select ccode from course where dno =" +dno;
        
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
            Statement stm = con.createStatement() ;
            ResultSet res = stm.executeQuery(sql_command) ;
            while( res.next() )
            {
                String temp = res.getString("ccode");
                course_list.addItem(temp) ;
            }
        }
        catch(SQLException f)
        {
            f.printStackTrace();
        }
        // --------------------------------- END --------------------------------------
        
        background.add(course_list) ;
        
        cname = new JLabel("") ;
        
        cname.setBounds(60, 150, 700, 30) ;
        cname.setFont(new Font("Serif", Font.ITALIC, 20));
        background.add(cname) ;
        
        f1 = new JRadioButton("",true) ;
        f1.setActionCommand("1");
        f2 = new JRadioButton("") ;
        f2.setActionCommand("2") ;
        f3 = new JRadioButton("") ;
        f3.setActionCommand("3") ;
        
        bg = new ButtonGroup() ;
        bg.add(f1) ;
        bg.add(f2) ;
        bg.add(f3) ;

        //------------------------- Faculty column -----------------------------
        
        JLabel name_label = new JLabel("Faculty Name") ;
        name_label.setBounds(60, 220, 150, 25) ;
        name_label.setFont(new Font("Serif", Font.ITALIC, 20)) ;
        background.add(name_label) ;
        
        fname1 = new JLabel("") ;
        fname1.setBounds(60,260,150,30) ;
        fname1.setFont(new Font("Serif", Font.ITALIC, 20)) ;
        background.add(fname1) ;
        
        fname2 = new JLabel("") ;
        fname2.setBounds(60,310,150,30) ;
        fname2.setFont(new Font("Serif", Font.ITALIC, 20)) ;
        background.add(fname2) ;
        
        fname3 = new JLabel("") ;
        fname3.setBounds(60,360,150,30) ;
        fname3.setFont(new Font("Serif",Font.ITALIC, 20)) ;
        background.add(fname3) ;
        
        //-------------------------- Slot column -------------------------------
        
        JLabel slot_name = new JLabel("Slot") ;
        slot_name.setBounds(320, 220, 100, 15) ;
        slot_name.setFont(new Font("Serif", Font.ITALIC, 20)) ;
        background.add(slot_name) ;
        
        slot1 = new JLabel("") ;
        slot1.setBounds(322, 260, 50, 15) ;
        slot1.setFont(new Font("Serif", Font.ITALIC, 20));
        background.add(slot1) ;
        
        slot2 = new JLabel("") ;
        slot2.setBounds(322, 310, 50, 15) ;
        slot2.setFont(new Font("Serif", Font.ITALIC, 20));
        background.add(slot2) ;
        
        slot3 = new JLabel("") ;
        slot3.setBounds(322, 360, 50, 15) ;
        slot3.setFont(new Font("Serif", Font.ITALIC, 20));
        background.add(slot3) ;
        //--------------------------- Radio Button Column -----------------------------
              
        f1.setBounds(670, 260, 30, 20) ;
        background.add(f1) ;
        f1.setOpaque(false) ;
        f2.setBounds(670, 310, 30, 20) ;
        background.add(f2) ;
        f2.setOpaque(false);
        f3.setBounds(670, 360, 30, 20) ;
        background.add(f3) ;
        f3.setOpaque(false);
        
        JLabel seats_ava = new JLabel("Choose") ;
        seats_ava.setBounds(650, 220, 150, 15) ;
        seats_ava.setFont(new Font("Serif", Font.ITALIC, 20)) ;
        background.add(seats_ava) ;
          
        JLabel dot = new JLabel("------------------------------------------------------------------------------------------------------------------------------------------------------------------------") ;
        
        dot.setBounds(55, 240, 710, 10) ;
        background.add(dot);
     
        register = new JButton("Register");
        register.setBounds(150, 500, 120, 30) ;
        background.add(register) ;
        register.addActionListener(new ActionListener(){
            
            @Override
             public void actionPerformed(ActionEvent ae)
             {
                if( ae.getActionCommand().equals("Register") )
                {
                    String slot = "";
                    int temp_fid = 0 ;
                    String sub_code = null ;
                    String selected = bg.getSelection().getActionCommand() ;
                
                    if( selected.equals("1") )
                    {
                        slot = slot1.getText() ;
                        temp_fid = 0 ;
                    }
                    else if( selected.equals("2"))
                    {
                        slot = slot2.getText() ;
                        temp_fid = 1 ;
                    }
                    else if( selected.equals("3") )
                    {
                        slot = slot3.getText() ;
                        temp_fid = 2 ;
                    }
                    
                        registeration(register_no, course_code, faculty_id[temp_fid], slot) ;
                }
             }
                }) ;
                
        
        logout = new JButton("Logout") ;
        logout.setBounds(480, 500, 120, 30) ;
        background.add(logout) ;
        logout.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                new Login() ;
                dispose() ;
            }
        });
        
        Timetable = new JButton("Timetable") ;
        Timetable.setBounds(317, 500, 120, 30) ;
        background.add(Timetable) ;
        Timetable.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                new RegisteredCourseView(register_no) ;
                dispose() ;
            }
        });
        
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
            
        course_code = (String)e.getItem() ;
        
        String title = "" ;
        String sql = "select cname from course where ccode = '" +course_code +"'" ;
        fid_index = 0 ;
        
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
            Statement stm = con.createStatement() ;
            ResultSet res = stm.executeQuery(sql) ;
                 
            while( res.next() )
            {
                title = res.getString("cname") ;
            }
            
            flag1 = 1 ; flag2 = 0 ; flag3 = 0 ;
            
            String temp_fname, temp_slot ;
            
            sql = "select name, slot, fid from faculty where ccode='" +course_code +"'" ;
            res = stm.executeQuery(sql) ;
            
            while( res.next() )
            {
                temp_fname = res.getString("name") ;
                temp_slot = res.getString("slot") ;
                
                if( flag3 == 1 )
                {
                    flag3 = 0 ;
                    faculty_id[fid_index++] = res.getInt("fid");
                    fname3.setText(temp_fname);
                    slot3.setText(temp_slot);
                }
                
                if( flag2 == 1 )
                {
                    flag2 = 0 ;
                    flag3 = 1 ;
                    faculty_id[fid_index++] = res.getInt("fid");
                    fname2.setText(temp_fname) ;
                    slot2.setText(temp_slot) ;
                }
                
                if( flag1 == 1 )
                {
                    flag1 = 0 ; 
                    flag2 = 1 ;
                    faculty_id[fid_index++] = res.getInt("fid");
                    fname1.setText(temp_fname) ;
                    slot1.setText(temp_slot) ;
                }
            }
        }
        catch(SQLException f)
        {
            f.printStackTrace();
        }
        
        cname.setText("Course Name: " +title) ;
    }
    
    public void registeration(String regno, String ccode, int fid, String slot) 
    {
        int sum_crd = 0 ;
        
        String sql_cmd = "SELECT credits FROM course, registered WHERE course.ccode = registered.ccode AND registered.regno ='" +regno +"'" ;
        
        try{
            
        Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
        Statement st = co.createStatement() ;
        ResultSet r = st.executeQuery(sql_cmd) ;
        
        while( r.next() )
        {
            sum_crd += r.getInt("credits") ;
        }
        
        }catch(SQLException s)
        {
            s.printStackTrace();
        }
        
        if( sum_crd+2 < 12 )
        { 
        String sql = "INSERT INTO registered VALUES('"+regno +"','"+ccode+"'," +fid +",'" +slot +"')" ;
        
        try{
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "forgotpass1") ;
        Statement stm = con.createStatement() ;
        stm.executeUpdate(sql);
        flag = 1 ;
        }
        catch(SQLException s)
        {
            JOptionPane.showMessageDialog(null, " You have already Registered the Course.") ;   
        }
        
        if( flag == 1 )
        {
            JOptionPane.showMessageDialog(null, " Registered Successfully ") ;
            flag = 0 ;
        }
       }else
        {
            JOptionPane.showMessageDialog(null," You have registered Maximum Credits ") ; 
        }
    }
}
    
    

